	$(document).ready(function(){
	$(".sidenav").sidenav();
  	});
  	// código acima é sobre o side-nav